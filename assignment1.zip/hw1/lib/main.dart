// import 'dart:js';

import 'package:flutter/material.dart';

    void main() {
      runApp(MaterialApp(
        debugShowCheckedModeBanner: false,
        home :Scaffold(
      backgroundColor: Colors.white,
        appBar: AppBar(
            leading:Icon(Icons.dehaze_rounded , color: Colors.grey,size: 30),
          title:const Text("Layouts"
              ,style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold ,color: Colors.black)) ,
          centerTitle: true,
          backgroundColor: Colors.white,

            actions:<Widget>[
              Icon(Icons.search,color: Colors.grey , size: 30)
            ]

        ) ,


        body:SingleChildScrollView(
       child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,

          children: [

      Image.asset('images/gift2.jpg',
          width: 600.0,
          height: 240.0,
          fit: BoxFit.cover

      ),
          SizedBox(
            height: 15,
          ),

          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
            "My Birthday"
              ,style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold ,color: Colors.black,)
        ),
          ),
            const Divider(
              height: 30,
              color: Colors.black26,
            ),

      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text(
            "It's going to be a nice birthday.We are going out for dinner at my favoriate place"
            ,style: TextStyle(fontSize: 12,fontWeight: FontWeight.normal ,color: Colors.black26)

        ),
      ), const Divider(
              height: 30,
              color: Colors.black26,
            ),
            Padding(
                padding: EdgeInsets.fromLTRB(10,0,25,10),
     child: Row(

        mainAxisAlignment: MainAxisAlignment.start,

          children: [

          Icon(Icons.sunny,color: Colors.orange , size: 30),

                Padding(
                    padding: EdgeInsets.fromLTRB(10,8,25,10),
         child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('81 Clear ' ,
                    style: TextStyle(fontWeight: FontWeight.normal,
                        color: Colors.red)
                ),

                Text( '4500 san antonio street',
                    style: TextStyle(fontWeight: FontWeight.normal
                        ,color: Colors.black26)
                )

              ]
          )
                )
        ]
      )
                
      ),








            const Divider(
              height: 30,
              color: Colors.black26,
            ),
            // GridView.builder(
            //   itemCount: 4,
            //     gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3), itemBuilder:( context,index){
                 Padding(
                    padding: EdgeInsets.all(8.0),
                child:Container(
                      height: 50,
                  width: 100,

                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(10)
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Icon(Icons.card_giftcard,color: Colors.cyan,size: 30
              ),

                        Text( 'Gift',
                            style: TextStyle(fontWeight: FontWeight.normal
                                ,color: Colors.black26)
                        ),



            //       ]
            //     ),
            //
            //     ),
            //
            //     );
            //
            // }
            //
            // )



    ],
    ),
                  )


    )
                 ),

                     Divider(
                 height: 30,
                 color: Colors.black26,
                 )

            ,Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              CircleAvatar(
                    radius: 60,
                    backgroundImage: AssetImage('images/food1.jpeg')),
              CircleAvatar(
                  radius: 60,
                  backgroundImage: AssetImage('images/food2.jpeg')),
              CircleAvatar(
                  radius: 60,
                  backgroundImage: AssetImage('images/food3.jpeg')),
              ]
            ),

























    ])
  )
      )


      )


      );
}